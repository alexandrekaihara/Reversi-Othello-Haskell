Universidade de Brasilia - Instituto de Ciencias Exatas
Departamento de Ciencia da Computacao
CIC 116343- Linguagens de Programa��o
2019.2 - Turma A - Professor Luis Pacheco

Autores: 
18/0029690 - Alexandre Mitsuru Kaihara
18/0016326 - Felipe Xavier Barbosa da Silva

Trabalho Reversi

-Diretiva de compilacao utilizada:
	ghc main.hs
